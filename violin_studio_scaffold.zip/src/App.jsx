import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>🎻 Violin Studio</h1>
      <p>Welcome to the AI-Optimized Acoustic Enhancer Dashboard!</p>
    </div>
  );
}

export default App;